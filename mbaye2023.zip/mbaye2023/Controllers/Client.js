import Client from "../models/Clients.js";

//creer un client
 export const createClient = async (req, res) => 
 
 { try { 
    const client = await Client.create(req.body);
     res.status(201).json(client); 
} 
catch (error) { res.status(500).json({ message: "Error creating client" });
 }
 };
 
 //client par id
 export const getClientById = async (req, res) =>
  { try { 
    const { id } = req.params;
  const client = await Client.findByPk(id);
  res.json(client);
 }
  catch (error) { res.status(500).json({ message: "Error retrieving client" });
 } 
};

 //mise a jour client

 export const updateClient = async (req, res) => 
 { try { 
    const { id } = req.params;
  const [numRows, [updatedClient]] = await Client.update(req.body, { 
    returning: true, where: { id }, });
   res.json(updatedClient);
 } 
 catch (error) { res.status(500).json({ message: "Error updating client" });
 } 
};

//Supprimer

export const deleteClient = async (req, res) => { 
    
    try { const { id } = req.params; 
    await Client.destroy({ where: { id } });
     res.json({ message: "Client deleted successfully" });
 } catch (error) { res.status(500).json({ message: "Error deleting client" });
 } 
};