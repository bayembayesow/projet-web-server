//Importer le modèle d'utilisateur
import Users from "../models/Users.js";
//Créer un contrôleur pour créer un nouvel utilisateur
export const createUser = async (req, res) => {
     try { 
        const { nom, prenom, naissance, photo, telephone, email, motdepasse } = req.body;
 const newUser = await Users.create({ nom, prenom, naissance, photo, telephone, email, motdepasse });
res.status(201).json(newUser);
 } catch (error) {console.log(error);
    res.status(500).json({ message: "Une erreur est survenue lors de la création de l'utilisateur." }
    );
     } };
     //Créer un contrôleur pour récupérer tous les utilisateurs
     export const getAllUsers = async (req, res) => {
        try {
            const users = await Users.findAll();
      res.status(200).json(users);
    } catch (error) {console.log(error);
         res.status(500).json({ message: "Une erreur est survenue lors de la récupération des utilisateurs." });
         } };
         //Créer un contrôleur pour récupérer un utilisateur par son ID
         export   const getUserById = async (req, res) => {
             const { id } = req.params; 
         try { 
            const user = await Users.findByPk(id);
          if (!user) {à
             res.status(404).json({ message: 'Lutilisateur avec lID ${id} na pas été trouvé.' }
             ); 
    }
     else { res.status(200).json(user);
        
        } }
     catch (error) {console.log(error);
             res.status(500).json({ message: "Une erreur est survenue lors de la récupération de l'utilisateur." }); 
        } };
            //Créer un contrôleur pour mettre à jour un utilisateur
            export const updateUser = async (req, res) => {
                 const { id } = req.params; 
             const { nom, prenom, naissance, photo, telephone, email, motdepasse } = req.body; 
             try {const user = await Users.findByPk(id);
                  if (!user) { res.status(404).json({ message: 'Lutilisateur avec lID ${id} na pas été trouvé.' });
                 }
                  else {  user.nom = nom;
                      user.prenom = prenom; 
                    user.naissance = naissance;
                     user.photo = photo;
                     user.telephone = telephone;
                       user.email = email; 
                      user.motdepasse = motdepasse;
                    await user.save(); 
                    res.status(200).json(user);
                 } } catch (error) {console.log(error);
                         res.status(500).json({ message: "Une erreur est survenue lors de la mise à jour de l'utilisateur." });
 } };

 export const deleteUser = async (req, res) => { 
     const { id } = req.params; 
     try {
         const user = await Users.findByPk(id); 
          if (!user) { res.status(404).json({ message: 'lutilisateur avec lID ${id} na pas été trouvé. '}
          );} 
          else { await user.destroy(); 
            res.status(204).json(); 
        }  }
         catch (error) {
             console.log(error); 
              res.status(500).json({ message: "Une erreur est survenue lors de la suppression de l'utilisateur." }); 
 } };