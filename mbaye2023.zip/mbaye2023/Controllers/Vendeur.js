import Vendeur from "../models/Vendeurs.js";

export const getAllVendeurs = async (req, res) => {
  try {
    const vendeurs = await Vendeur.findAll();
    res.status(200).json(vendeurs);
  } catch (error) {
    console.log(error);
    res.status(500).json({ message: "Une erreur est survenue lors de la récupération des vendeurs." });
  }
};
