import express from "express"; 
import { createUser, getAllUsers, getUserById, updateUser, deleteUser } from "../controllers/Users.js";
const router = express.Router();
//Créer une route pour créer un nouvel utilisateur
router.post("/", createUser);
//Créer une route pour récupérer tous les utilisateurs
router.get("/", getAllUsers);
//Créer une route pour récupérer un utilisateur par son ID
router.get("/:id", getUserById);
//Créer une route pour mettre à jour un utilisateur
router.put("/:id", updateUser);
//Créer une route pour supprimer un utilisateur
router.delete("/:id", deleteUser);

export default router;