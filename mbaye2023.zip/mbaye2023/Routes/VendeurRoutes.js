import express from "express";
import { getAllVendeurs } from "../controllers/Vendeur.js";

const router = express.Router();

router.get("/vendeurs", getAllVendeurs);

export default router;
