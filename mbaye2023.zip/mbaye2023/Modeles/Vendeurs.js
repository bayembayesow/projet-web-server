import database from "../connexion.js";
import {DataTypes} from  'sequelize'

const Vendeur=database.define('Vendeur',{
    prenom:{type:DataTypes.STRING,allowNull:false},
    nom:{type:DataTypes.STRING,allowNull:false},
    date_de_naissance:{type:DataTypes.DATEONLY},
   
},
    {
        timestamps:false
    })

export default Vendeur