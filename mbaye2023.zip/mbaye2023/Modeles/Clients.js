import database from "../connexion.js";
import {DataTypes} from  'sequelize'

const Client=database.define('Client',{
    prenom:{type:DataTypes.STRING,allowNull:false},
    nom:{type:DataTypes.STRING,allowNull:false},
    date_de_naissance:{type:DataTypes.DATEONLY},
    adresse:{type:DataTypes.STRING,allowNull:false},
    telephone:{type:DataTypes.STRING,allowNull:false},
},
    {
        timestamps:false
    })

export default Client
