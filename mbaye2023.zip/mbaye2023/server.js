
import express from 'express'
import bodyParser from 'body-parser'
import cors from 'cors'
import helmet from 'helmet'
import compression from 'compression'


import database from './connexion.js'
import VendeurRoutes from "./routes/VendeurRoutes.js";
import  ClientRoutes from "./routes/ClientRoutes.js";
import UsersRoutes from "./routes/UsersRoutes.js";
import RolesRoutes from "./routes/RoleRoute.js"
import AutomobileRoute from "./routes/AutomobileRoutes.js"
import EchangeVoiture  from './models/EchangeVoiture.js'    
database.sync()

const PORT = process.env.PORT
const app = express()

app.use(helmet())
app.use(compression())
app.use(cors())
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false }))

// Les routes
app.use("/Vendeur", VendeurRoutes);
app.use("/Client" , ClientRoutes)
app.use("/Users" , UsersRoutes)
app.use("/Roles",RolesRoutes)
app.use("/Automobile", AutomobileRoute)
app.use("/EchangeVoiture",EchangeVoiture)
app.listen(PORT, () => console.log(`Serveur running on port ${PORT}`))







