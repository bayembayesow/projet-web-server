import database from "../connexion.js";
import {DataTypes} from  'sequelize'

const Automobile =database.define('Automobile',{
    Serie:{type:DataTypes.STRING,allowNull:false},
    Annee:{type:DataTypes.STRING,allowNull:false},
    Marque:{type:DataTypes.STRING,allowNull:false},
    
    Modele:{type:DataTypes.STRING,allowNull:false},
    prix_Afficher:{type:DataTypes.STRING,allowNull:false},
    Kilometrage:{type:DataTypes.STRING,allowNull:false},
},
    {
        timestamps:false
    })

export default Automobile
