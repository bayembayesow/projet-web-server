//Importer la base de donnee pour creer les modeles
import database from "../connexion.js";
import { DataTypes } from 'sequelize'

//Modele de la table EchangeVoiture
const EchangeVoiture = database.define('EchangeVoiture', {
    id_Echange: { type: DataTypes.STRING, allowNull: false },
    NumeroSerie: { type: DataTypes.STRING, allowNull: false },
    AnnéeFabrication:{type:DataTypes.STRING,allowNull:false},
    marque:{type:DataTypes.STRING,allowNull:false},
    modèle:{type:DataTypes.STRING,allowNull:false},
    kilométrage:{type:DataTypes.STRING,allowNull:false},
    PrixAttribué:{type:DataTypes.STRING,allowNull:false},
   id_Vente:{type:DataTypes.STRING,allowNull:false},
},
    { //Ajouter cet objet pour ne pas avoir les colonnes createdAt and updatedAt automatiquement
        timestamps: false
    })

export default EchangeVoiture



