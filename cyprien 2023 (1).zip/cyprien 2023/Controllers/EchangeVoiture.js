import EchangeVoiture from "../models/EchangeVoiture.js";

export const getAllEchangeVoitures = async (req, res) => {
  try {
    const echangeVoitures = await EchangeVoiture.findAll();
    res.status(200).json(echangeVoitures);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

 export const getEchangeVoitureById = async (req, res) => {
  const { id } = req.params;
  try {
    const echangeVoiture = await EchangeVoiture.findByPk(id);
    if (!echangeVoiture) {
      res.status(404).json({ message: `Echange de voiture avec l'ID ${id} introuvable` });
    } else {
      res.status(200).json(echangeVoiture);
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
export const createEchangeVoiture = async (req, res) => {
  const { NumeroSerie, AnnéeFabrication, marque, modèle, kilométrage, PrixAttribué, id_Vente } = req.body;
  try {
    const newEchangeVoiture = await EchangeVoiture.create({ NumeroSerie, AnnéeFabrication, marque, modèle, kilométrage, PrixAttribué, id_Vente });
    res.status(201).json(newEchangeVoiture);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
export const updateEchangeVoiture = async (req, res) => {
  const { id } = req.params;
  const { NumeroSerie, AnnéeFabrication, marque, modèle, kilométrage, PrixAttribué, id_Vente } = req.body;
  try {
    const echangeVoiture = await EchangeVoiture.findByPk(id);
    if (!echangeVoiture) {
      res.status(404).json({ message: `Echange de voiture avec l'ID ${id} introuvable` });
    } else {
      await echangeVoiture.update({ NumeroSerie, AnnéeFabrication, marque, modèle, kilométrage, PrixAttribué, id_Vente });
      res.status(200).json({ message: `Echange de voiture avec l'ID ${id} mis à jour avec succès` });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
export const deleteEchangeVoiture = async (req, res) => {
  const { id } = req.params;
  try {
    const echangeVoiture = await EchangeVoiture.findByPk(id);
    if (!echangeVoiture) {
      res.status(404).json({ message: `Echange de voiture avec l'ID ${id} introuvable` });
    } else {
      await echangeVoiture.destroy();
      res.status(200).json({ message: `Echange de voiture avec l'ID ${id} supprimé avec succès` });
    }
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


