import Automobile from '../models/Automobile.js'; // Récupérer toutes les automobiles
export const getAllAutomobiles = async (req, res) => {
try { 
    const automobiles = await Automobile.findAll();
    res.status(200).json(automobiles);
    } 
    catch (error) {
    console.log(error);
    res.status(500).json({ message: "Erreur lors de la récupération des automobiles." });
    }
};

// Récupérer une automobile par son id
export const getAutomobileById = async (req, res) => {
try {
    const automobile = await Automobile.findByPk(req.params.id);
    if (!automobile) throw new Error("Automobile non trouvée.");
    res.status(200).json(automobile);
    } catch (error) {
    console.log(error);
    res.status(404).json({ message: "Automobile non trouvée." });
    }
};

// Ajouter une nouvelle automobile
export const addAutomobile = async (req, res) => {
try {
     const newAutomobile = await Automobile.create(req.body);
    res.status(201).json(newAutomobile);
    } 
    catch (error) {
    console.log(error); 
    res.status(500).json({ message: "Erreur lors de l'ajout d'une nouvelle automobile." });
    }
};

// Modifier une automobile existante
export const updateAutomobile = async (req, res) => {
    try {
     const automobile = await Automobile.findByPk(req.params.id);
    if (!automobile) throw new Error("Automobile non trouvée.");
    await automobile.update(req.body);
    res.status(200).json(automobile);
    } 
    catch (error) {
    console.log(error);
    res.status(404).json({ message: "Automobile non trouvée." });
    }
};

// Supprimer une automobile
export const deleteAutomobile = async (req, res) => {
try {
    const automobile = await Automobile.findByPk(req.params.id);
     if (!automobile) throw new Error("Automobile non trouvée.");
    await automobile.destroy();
    res.status(204).json({ message: "Automobile supprimée." }); 
    } 

catch (error) {
     console.log(error);
     res.status(404).json({ message: "Automobile non trouvée." });
     }
};