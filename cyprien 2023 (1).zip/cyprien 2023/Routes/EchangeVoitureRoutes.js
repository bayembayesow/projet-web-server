import express from 'express';
import { createEchangeVoiture, getAllEchangesVoiture,  getEchangeVoitureById,updateEchangeVoiture, deleteEchangeVoiture,} from '../controllers/EchangeVoiture.js';
const router = express.Router();
 
// Route pour créer un nouvel échange de voiture
router.post('/echangeVoitures', createEchangeVoiture);
 
// Route pour récupérer tous les échanges de voiture
router.get('/echangeVoitures', getAllEchangesVoiture);
 
// Route pour récupérer un échange de voiture par son ID
router.get('/echangeVoitures/:id', getEchangeVoitureById);
 
// Route pour mettre à jour un échange de voiture
router.put('/echangeVoitures/:id', updateEchangeVoiture);
 
// Route pour supprimer un échange de voiture
router.delete('/echangeVoitures/:id', deleteEchangeVoiture);
 
export default router;

