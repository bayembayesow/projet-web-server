import express from 'express'; 
import { getAllAutomobiles, getAutomobileById, addAutomobile, updateAutomobile, deleteAutomobile } from "../controllers/Automobile.js"

const router = express.Router();

router.get("/automobiles", getAllAutomobiles); 
router.get('/automobiles/:id', getAutomobileById); 
router.post('/automobiles', addAutomobile);
router.put('/automobiles/:id', updateAutomobile)
router.delete('/automobiles/:id', deleteAutomobile)

export default router;
